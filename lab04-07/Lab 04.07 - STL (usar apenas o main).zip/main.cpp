#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main(){

	long long int a, d;
	
	while(cin >> a >> d && a != 0 && d != 0){

	}


}